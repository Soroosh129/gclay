extern void drm_gem_object_release_wrap(struct drm_gem_object *obj);
extern int gem_create_mmap_offset(struct drm_gem_object *obj);
