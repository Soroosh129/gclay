To build sass2cubin:

1. Type `./configure' or `make -f genmake.txt' to build the Makefile.

2. Type `make' to compile the sass2cubin.

3. Type `sudo make install' to install the sass2cubin to /usr/local/gdev/bin.

