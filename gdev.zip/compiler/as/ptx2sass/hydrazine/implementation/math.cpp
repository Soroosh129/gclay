/*!	\file math.cpp
*
*	\brief source file for common math functions.
*
*	\author Gregory Diamos
*
*	\date : 9/27/2007
*	
*
*
*/

#ifndef MATH_CPP_INCLUDED
#define MATH_CPP_INCLUDED

#include "math.h"

namespace hydrazine
{



	
}


#endif
