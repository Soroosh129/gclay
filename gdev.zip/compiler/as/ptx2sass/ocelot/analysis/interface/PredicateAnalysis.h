/*! \file   PredicateAnalysis.h
	\date   Friday July 29, 2011
	\author Gregory Diamos <gregory.diamos@gatech.edu>
	\brief  The header file for the PredicateAnalysis class.
*/

#pragma once

namespace analysis
{


}


