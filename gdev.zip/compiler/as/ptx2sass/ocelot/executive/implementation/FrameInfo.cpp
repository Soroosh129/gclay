/*! \file   FrameInfo.cpp
	\author Gregory Diamos <gregory.diamos@gatech.edu>
	\date   Friday February 8, 2013
	\brief  The source file for the FrameInfo class.
*/

// Ocelot Includes 
#include <ocelot/executive/interface/FrameInfo.h>

namespace executive
{

}

