#define DIRPATH "/home/soroosh/Project/gdev/test/cuda/kernel/mmul"
