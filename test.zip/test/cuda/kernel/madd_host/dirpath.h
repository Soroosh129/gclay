#define DIRPATH "/home/soroosh/Project/gdev/test/cuda/kernel/madd_host"
